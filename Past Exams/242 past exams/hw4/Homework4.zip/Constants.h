#ifndef HW4_CONSTANTS_H
#define HW4_CONSTANTS_H

enum Team{
	BARBARIANS,
	KNIGHTS
};

enum Goal{
	ATTACK,
	HEAL,
	TO_ALLY,
	TO_ENEMY,
	CHEST,
	NO_GOAL
};


#endif
